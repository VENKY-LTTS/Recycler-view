package com.example.recyclerview

class JsonData : ArrayList<JsonDataItem>()